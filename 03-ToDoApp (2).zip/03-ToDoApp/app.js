const input = document.querySelector(".customInput");
const form = document.querySelector(".form");
const list = document.querySelector(".toDoList");

form.addEventListener("submit",function (e) {
    e.preventDefault();
    console.log(input.value);
    create()
    input.value="";
})

function create(){
    const li = document.createElement("li");
    const delbutton = document.createElement("button")
    li.innerText = input.value;
    delbutton.innerText = "Delete"
    li.className = "todoitem"
    delbutton.className = "deleteBtn"

    delbutton.addEventListener("click",deleteTodo);

    li.appendChild(delbutton);
    list.appendChild(li);
}

function deleteTodo(e){
    console.log(e.target.parentElement.remove());
}

